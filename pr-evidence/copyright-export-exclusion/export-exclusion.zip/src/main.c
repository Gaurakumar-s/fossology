// Copyright (c) 2026 Application Example Ltd.
// SPDX-License-Identifier: MIT
int main(void) { return 0; }
