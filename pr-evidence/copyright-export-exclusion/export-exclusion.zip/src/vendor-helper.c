// Copyright (c) 2026 Helper Example Ltd.
// SPDX-License-Identifier: MIT
int helper(void) { return 2; }
